/*
Rob Parke
Viterbi School of Engineering
University of Southern California
Java, C++, and Python Review
*/

public class Shape {    
	public void display() {        
		System.out.println("Going down the road!");    
	} 
}